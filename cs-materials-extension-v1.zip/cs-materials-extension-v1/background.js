
  let opening = false;
  chrome.action.onClicked.addListener(async () => {
    if (opening) return;
    opening = true;
    try {
      const url = chrome.runtime.getURL('app.html');
      const windows = await chrome.windows.getAll({populate:true});
      const existing = windows.find(w =>
        w.type === 'popup' && w.tabs?.some(t => t.url === url));
      if (existing) {
        await chrome.windows.update(existing.id,{focused:true});
      } else {
        await chrome.windows.create({
          url,type:'popup',width:480,height:760,focused:true
        });
      }
    } catch (e) {
      console.error('Unable to open CS materials window',e);
    } finally {
      opening = false;
    }
  });
  