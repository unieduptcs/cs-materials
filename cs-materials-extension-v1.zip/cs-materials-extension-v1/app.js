'use strict';

const BASE = 'https://unieduptcs.github.io/cs-materials/';
const MANIFEST = BASE + 'materials.json';
const $ = id => document.getElementById(id);

const MATERIAL_GROUPS = ['常用圖', '新查詢進度圖', '限時活動'];

const DEFAULT_TEXT_GROUP = '未分類';
let textGroups = [DEFAULT_TEXT_GROUP];
let selectedTextGroup = '';

let selectedGroup = '常用圖';
let selectedSubject = '';

let templates = [], materials = [], materialOrder = [];
let tab = 'text', editingId = null, selected = null;
let dragId = null, dragTab = null, lastUpdated = null;
let offline = false, loading = false, toastTimer;

const preparedFiles = new Map();
const fileTasks = new Map();
let saveQueue = Promise.resolve();

function notify(message) {
  const toast = $('toast');
  if (!toast) return;

  toast.textContent = message;
  toast.hidden = false;

  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.hidden = true;
  }, 4500);
}

function persist(data) {
  saveQueue = saveQueue
    .then(() => chrome.storage.local.set(data))
    .catch(e => {
      console.error(e);
      notify('儲存失敗，請匯出備份並檢查儲存空間。');
    });

  return saveQueue;
}

function el(tag, cls, text) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

function btn(label, title, handler, cls = '') {
  const node = el('button', cls, label);
  node.type = 'button';
  node.title = title;
  node.setAttribute('aria-label', title);
  node.addEventListener('click', handler);
  return node;
}

function installFilterStyles() {
  if ($('material-filter-styles')) return;

  const style = el('style');
  style.id = 'material-filter-styles';
  style.textContent = `
    #material-filters,
    #text-filters {
      margin: 0 0 10px;
    }

    #material-filters .filter-row,
    #text-filters .filter-row {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      align-items: center;
    }

    #material-filters .filter-button,
    #text-filters .filter-button {
      padding: 6px 9px;
      font-size: 12px;
      line-height: 1.4;
      border: 1px solid #dce2ec;
      border-radius: 7px;
      background: #fff;
      color: #3b4a60;
      cursor: pointer;
    }

    #material-filters .group-filters .filter-button {
      flex: 1;
      white-space: nowrap;
    }

    #material-filters .filter-button:hover,
    #text-filters .filter-button:hover {
      background: #eef3ff;
      border-color: #b6c8f8;
    }

    #material-filters .filter-button.active,
    #text-filters .filter-button.active {
      color: #315bc7;
      background: #edf3ff;
      border-color: #b8c9f4;
      font-weight: 600;
    }

    #material-filters .subject-filters,
    #text-filters .subject-filters {
      margin-top: 7px;
    }

    #material-filters .subject-filters .filter-button,
    #text-filters .subject-filters .filter-button {
      padding: 4px 9px;
      font-size: 11px;
    }

    #material-filters .filter-button:focus-visible,
    #text-filters .filter-button:focus-visible {
      outline: 2px solid #4270e0;
      outline-offset: 2px;
    }

    #material-filters[hidden],
    #text-filters[hidden] {
      display: none !important;
    }

    #edit-group {
      border: 1px solid #dce2ec;
      border-radius: 8px;
      padding: 8px;
      font-size: 14px;
      background: #fff;
    }

    body.materials-mode #meta {
      display: none !important;
    }

    #tools-text {
      flex-wrap: wrap;
    }

    #tools-text #meta {
      margin-top: 0;
      margin-left: 4px;
      line-height: 1.4;
      align-self: center;
      white-space: nowrap;
      color: #738096;
    }

    #edit-groups {
      white-space: nowrap;
    }
  `;

  document.head.append(style);
}

function ensureGroupEditButton() {
  if ($('edit-groups')) return;

  const addButton = $('add');
  if (!addButton || !addButton.parentNode) return;

  const editButton = btn(
    '編輯分組',
    '修改或刪除文字分組',
    () => openGroupManager(),
    ''
  );

  editButton.id = 'edit-groups';

  addButton.insertAdjacentElement('afterend', editButton);
}

function validateTemplates(value) {
  if (!Array.isArray(value) || value.length > 2000) {
    throw new Error('Template 清單格式不正確或數量過多。');
  }

  const ids = new Set();

  return value.map(t => {
    if (!t ||
        typeof t.title !== 'string' || !t.title.trim() ||
        typeof t.content !== 'string' || !t.content.trim() ||
        t.title.length > 120 ||
        t.content.length > 100000) {
      throw new Error('每份 Template 必須有有效名稱及內容。');
    }

    let id = typeof t.id === 'string' && t.id && t.id.length <= 100
      ? t.id
      : crypto.randomUUID();

    if (ids.has(id)) id = crypto.randomUUID();
    ids.add(id);

    const group = typeof t.group === 'string' && t.group.trim()
      ? t.group.trim()
      : DEFAULT_TEXT_GROUP;

    return {
      id,
      title: t.title,
      content: t.content,
      group
    };
  });
}

function validateTextGroups(value) {
  if (!Array.isArray(value)) return [DEFAULT_TEXT_GROUP];

  const cleaned = value
    .filter(g => typeof g === 'string')
    .map(g => g.trim())
    .filter(Boolean)
    .filter(g => g.length <= 40);

  const unique = [...new Set(cleaned)];

  if (!unique.includes(DEFAULT_TEXT_GROUP)) {
    unique.unshift(DEFAULT_TEXT_GROUP);
  }

  return unique.slice(0, 100);
}

function templateGroup(item) {
  return item.group || DEFAULT_TEXT_GROUP;
}

function syncTextGroupsFromTemplates() {
  const fromTemplates = templates
    .map(templateGroup)
    .filter(Boolean);

  textGroups = validateTextGroups([
    ...textGroups,
    ...fromTemplates
  ]);
}

async function renameTextGroup(oldName) {
  if (!oldName || oldName === DEFAULT_TEXT_GROUP) {
    return notify('「' + DEFAULT_TEXT_GROUP + '」不能改名。');
  }

  const name = prompt('請輸入新的分組名稱：', oldName);
  if (name === null) return;

  const newName = name.trim();

  if (!newName) return notify('分組名稱不能留空。');
  if (newName.length > 40) return notify('分組名稱最多 40 字。');
  if (newName === oldName) return;

  if (textGroups.includes(newName)) {
    return notify('已有相同名稱的分組。');
  }

  textGroups = textGroups.map(group =>
    group === oldName ? newName : group
  );

  templates = templates.map(template =>
    templateGroup(template) === oldName
      ? { ...template, group: newName }
      : template
  );

  if (selectedTextGroup === oldName) {
    selectedTextGroup = newName;
  }

  textGroups = validateTextGroups(textGroups);

  await persist({ templates, textGroups });
  render();
  notify('已修改分組名稱。');
}

async function deleteTextGroup(groupName) {
  if (!groupName || groupName === DEFAULT_TEXT_GROUP) {
    return notify('「' + DEFAULT_TEXT_GROUP + '」不能刪除。');
  }

  const count = templates.filter(template =>
    templateGroup(template) === groupName
  ).length;

  const message = count
    ? '刪除分組「' + groupName + '」？\n\n' +
      '此分組內 ' + count + ' 份文字會移到「' + DEFAULT_TEXT_GROUP + '」。'
    : '刪除空分組「' + groupName + '」？';

  if (!confirm(message)) return;

  textGroups = textGroups.filter(group => group !== groupName);

  templates = templates.map(template =>
    templateGroup(template) === groupName
      ? { ...template, group: DEFAULT_TEXT_GROUP }
      : template
  );

  if (selectedTextGroup === groupName) {
    selectedTextGroup = DEFAULT_TEXT_GROUP;
  }

  textGroups = validateTextGroups(textGroups);

  await persist({ templates, textGroups });
  render();
  notify('已刪除分組。');
}

function openGroupManager() {
  syncTextGroupsFromTemplates();

  const editableGroups = textGroups.filter(group =>
    group !== DEFAULT_TEXT_GROUP
  );

  if (!editableGroups.length) {
    return notify('暫時未有可編輯的自定分組。');
  }

  const list = editableGroups
    .map((group, index) => (index + 1) + '. ' + group)
    .join('\n');

  const selectedIndexText = prompt(
    '請選擇要編輯的分組：\n\n' +
    list + '\n\n' +
    '請輸入分組編號：'
  );

  if (selectedIndexText === null) return;

  const selectedIndex = Number(selectedIndexText.trim());
  if (!Number.isInteger(selectedIndex) ||
      selectedIndex < 1 ||
      selectedIndex > editableGroups.length) {
    return notify('分組編號不正確。');
  }

  const groupName = editableGroups[selectedIndex - 1];

  const action = prompt(
    '正在編輯分組：「' + groupName + '」\n\n' +
    '1. 修改名稱\n' +
    '2. 刪除分組\n\n' +
    '請輸入 1 或 2：'
  );

  if (action === null) return;

  const actionValue = action.trim();

  if (actionValue === '1') {
    renameTextGroup(groupName);
  } else if (actionValue === '2') {
    deleteTextGroup(groupName);
  } else {
    notify('操作選項不正確。');
  }
}

function validateMaterials(data) {
  if (!data || !Array.isArray(data.items) || data.items.length > 1000) {
    throw new Error('教材清單格式不正確。');
  }

  const ids = new Set();
  const assetsBase = new URL('assets/', BASE);

  return data.items.map(m => {
    if (!m ||
        typeof m.id !== 'string' || !m.id ||
        typeof m.title !== 'string' || !m.title ||
        !['image', 'pdf'].includes(m.type) ||
        typeof m.path !== 'string' || !m.path.trim()) {
      throw new Error('教材項目缺少必要欄位。');
    }

    const path = m.path.trim();
    let url;

    try {
      url = new URL(path, BASE);
    } catch {
      throw new Error('教材路徑格式不正確：' + m.title);
    }

    if (url.origin !== assetsBase.origin ||
        !url.pathname.startsWith(assetsBase.pathname) ||
        url.username ||
        url.password) {
      throw new Error(
        '教材檔案必須放在公司 assets 資料夾：' +
        m.title + '（解析網址：' + url.href + '）'
      );
    }

    if (ids.has(m.id)) {
      throw new Error('教材 ID 重複：' + m.id);
    }

    ids.add(m.id);

    const group = typeof m.group === 'string'
      ? m.group.trim()
      : '';

    if (group && !MATERIAL_GROUPS.includes(group)) {
      throw new Error(
        '教材分類不正確：' + m.title +
        '（group：' + group +
        '；請使用常用圖、新查詢進度圖或限時活動）'
      );
    }

    return {
      id: m.id,
      title: m.title,
      type: m.type,
      category: typeof m.category === 'string' ? m.category : '',
      group: group || '常用圖',
      subject: typeof m.subject === 'string' && m.subject.trim()
        ? m.subject.trim()
        : '其他',
      path,
      url: url.href
    };
  });
}

function orderedMaterials() {
  const ranks = new Map(
    materialOrder.map((id, i) => [id, i])
  );

  return [...materials].sort((a, b) =>
    (ranks.get(a.id) ?? 100000) -
    (ranks.get(b.id) ?? 100000)
  );
}

function materialGroup(item) {
  return item.group || '常用圖';
}

function materialSubject(item) {
  return item.subject || '其他';
}

function renderMaterialFilters() {
  let panel = $('material-filters');

  if (!panel) {
    panel = el('div', 'filters');
    panel.id = 'material-filters';

    const toolsMaterials = $('tools-materials');
    if (toolsMaterials?.parentNode) {
      toolsMaterials.parentNode.insertBefore(panel, toolsMaterials);
    }
  }

  if (!panel) return;

  panel.hidden = tab !== 'materials';
  if (tab !== 'materials') return;

  const refreshButton = $('refresh');
  panel.replaceChildren();

  const groupRow = el('div', 'filter-row group-filters');
  groupRow.setAttribute('role', 'group');
  groupRow.setAttribute('aria-label', '教材分類');

  for (const group of MATERIAL_GROUPS) {
    const active = selectedGroup === group;

    const button = btn(
      group,
      '顯示' + group,
      () => {
        selectedGroup = group;
        selectedSubject = '';
        render();
      },
      'filter-button' + (active ? ' active' : '')
    );

    button.setAttribute('aria-pressed', String(active));
    groupRow.append(button);
  }

  if (refreshButton) {
    refreshButton.textContent = '↻';
    refreshButton.title = '重新整理教材';
    refreshButton.setAttribute('aria-label', '重新整理教材');
    refreshButton.className = 'filter-button refresh-icon';

    Object.assign(refreshButton.style, {
      flex: '0 0 34px',
      width: '34px',
      minWidth: '34px',
      padding: '0',
      fontSize: '22px',
      lineHeight: '1',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    });

    groupRow.append(refreshButton);
  }

  panel.append(groupRow);

  if (selectedGroup !== '新查詢進度圖') return;

  const subjects = [...new Set(
    materials
      .filter(item => materialGroup(item) === selectedGroup)
      .map(materialSubject)
  )].sort((a, b) => {
    if (a === b) return 0;
    if (a === '其他') return 1;
    if (b === '其他') return -1;
    return a.localeCompare(b, 'zh-HK');
  });

  if (selectedSubject && !subjects.includes(selectedSubject)) {
    selectedSubject = '';
  }

  const subjectRow = el('div', 'filter-row subject-filters');
  subjectRow.setAttribute('role', 'group');
  subjectRow.setAttribute('aria-label', '科目分類');

  function addSubjectButton(label, value) {
    const active = selectedSubject === value;

    const button = btn(
      label,
      '顯示' + label,
      () => {
        selectedSubject = value;
        render();
      },
      'filter-button' + (active ? ' active' : '')
    );

    button.setAttribute('aria-pressed', String(active));
    subjectRow.append(button);
  }

  addSubjectButton('全部科目', '');
  subjects.forEach(subject => addSubjectButton(subject, subject));

  panel.append(subjectRow);
}

function renderTextFilters() {
  let panel = $('text-filters');

  if (!panel) {
    panel = el('div', 'filters');
    panel.id = 'text-filters';

    const toolsText = $('tools-text');
    if (toolsText?.parentNode) {
      toolsText.parentNode.insertBefore(panel, toolsText);
    }
  }

  if (!panel) return;

  panel.hidden = tab !== 'text';
  if (tab !== 'text') return;

  syncTextGroupsFromTemplates();

  if (selectedTextGroup && !textGroups.includes(selectedTextGroup)) {
    selectedTextGroup = '';
  }

  panel.replaceChildren();

  const row = el('div', 'filter-row subject-filters');
  row.setAttribute('role', 'group');
  row.setAttribute('aria-label', 'Template 分組');

  function addGroupButton(label, value) {
    const active = selectedTextGroup === value;

    const button = btn(
      label,
      '顯示' + label,
      () => {
        selectedTextGroup = value;
        render();
      },
      'filter-button' + (active ? ' active' : '')
    );

    button.setAttribute('aria-pressed', String(active));
    row.append(button);
  }

  addGroupButton('全部', '');

  textGroups.forEach(group => {
    addGroupButton(group, group);
  });

  const addButton = btn(
    '+',
    '新增分組',
    async () => {
      const name = prompt('請輸入新分組名稱：');
      if (!name) return;

      const group = name.trim();

      if (!group) return notify('分組名稱不能留空。');
      if (group.length > 40) return notify('分組名稱最多 40 字。');

      if (textGroups.includes(group)) {
        selectedTextGroup = group;
        render();
        return;
      }

      textGroups.push(group);
      textGroups = validateTextGroups(textGroups);
      selectedTextGroup = group;

      await persist({ textGroups });
      render();
      notify('已新增文字分組。');
    },
    'filter-button'
  );

  row.append(addButton);
  panel.append(row);
}

function switchTab(value) {
  tab = value;

  const isText = tab === 'text';

  document.body.classList.toggle('text-mode', isText);
  document.body.classList.toggle('materials-mode', !isText);

  $('tab-text').classList.toggle('active', isText);
  $('tab-materials').classList.toggle('active', !isText);
  $('tab-text').setAttribute('aria-pressed', String(isText));
  $('tab-materials').setAttribute('aria-pressed', String(!isText));

  $('tools-text').hidden = !isText;
  $('tools-materials').hidden = isText;

  const editGroups = $('edit-groups');
  if (editGroups) editGroups.hidden = !isText;

  const textFilters = $('text-filters');
  if (textFilters) textFilters.hidden = !isText;

  const materialFilters = $('material-filters');
  if (materialFilters) materialFilters.hidden = isText;

  $('hint').textContent = isText
    ? '拖動 ⋮⋮ 排序。文字只儲存在此 Chrome 個人資料中。'
    : '⋮⋮ 用作排序；PDF 建議下載後從檔案總管拖到聊天視窗。';

  render();
}

function render() {
  renderMaterialFilters();
  renderTextFilters();

  const list = $('list');
  list.replaceChildren();

  const isText = tab === 'text';

  $('tools-text').hidden = !isText;
  $('tools-materials').hidden = isText;

  const editGroups = $('edit-groups');
  if (editGroups) editGroups.hidden = !isText;

  const meta = $('meta');
  if (meta) meta.hidden = !isText;

  let source = isText ? templates : orderedMaterials();

  if (isText) {
    if (selectedTextGroup) {
      source = source.filter(
        item => templateGroup(item) === selectedTextGroup
      );
    }
  } else {
    source = source.filter(
      item => materialGroup(item) === selectedGroup
    );

    if (selectedGroup === '新查詢進度圖' && selectedSubject) {
      source = source.filter(
        item => materialSubject(item) === selectedSubject
      );
    }
  }

  const visible = source;

  if (meta) {
    if (isText) {
      meta.textContent =
        (selectedTextGroup ? selectedTextGroup + ' · ' : '') +
        visible.length + ' / ' + templates.length +
        ' 份文字 · 本機儲存';
    } else {
      meta.textContent = '';
    }
  }

  if (!visible.length) {
    const message = isText
      ? (
          selectedTextGroup
            ? '此分組暫時未有文字 Template。'
            : '未有文字 Template。\n按「＋ 新增文字」開始。'
        )
      : loading
        ? '正在讀取公司教材…'
        : !materials.length
          ? '未有教材。請按「重新整理教材」。'
          : '此分類暫時未有教材。';

    list.append(el('div', 'empty', message));
    return;
  }

  for (const item of visible) {
    list.append(isText ? textCard(item) : materialCard(item));
  }
}

function reorderCard(card, item) {
  const grip = btn('⋮⋮', '拖動排序', () => {}, 'grip');
  grip.draggable = true;

  grip.addEventListener('dragstart', e => {
    dragId = item.id;
    dragTab = tab;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('application/x-cs-sort', item.id);
    e.dataTransfer.setData('text/plain', item.title);
    card.classList.add('dragging');
  });

  grip.addEventListener('dragend', () => {
    dragId = null;
    dragTab = null;
    document.querySelectorAll('.dragging,.over').forEach(n =>
      n.classList.remove('dragging', 'over')
    );
  });

  card.addEventListener('dragover', e => {
    if (dragId && dragTab === tab && dragId !== item.id) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      card.classList.add('over');
    }
  });

  card.addEventListener('dragleave', e => {
    if (!card.contains(e.relatedTarget)) {
      card.classList.remove('over');
    }
  });

  card.addEventListener('drop', e => {
    if (!dragId || dragTab !== tab) return;

    e.preventDefault();
    card.classList.remove('over');

    if (dragId === item.id) return;

    const ids = tab === 'text'
      ? templates.map(t => t.id)
      : orderedMaterials().map(m => m.id);

    const from = ids.indexOf(dragId);
    if (from < 0 || !ids.includes(item.id)) return;

    ids.splice(from, 1);
    ids.splice(ids.indexOf(item.id), 0, dragId);

    if (tab === 'text') {
      const lookup = new Map(templates.map(t => [t.id, t]));
      templates = ids.map(id => lookup.get(id)).filter(Boolean);
      persist({ templates });
    } else {
      materialOrder = ids;
      persist({ materialOrder });
    }

    dragId = null;
    dragTab = null;
    render();
  });

  return grip;
}

function textCard(item) {
  const card = el('article', 'card text-card');
  const row = el('div', 'row');

  row.append(reorderCard(card, item));

  const info = el('div', 'info');
  info.append(
    el('div', 'title', item.title),
    el('span', 'label', templateGroup(item)),
    el('div', 'text-content', item.content)
  );

  const actions = el('div', 'actions');
  actions.append(
    btn('⧉', '複製文字', () => copyText(item.content), 'icon'),
    btn('✎', '修改文字', () => openEditor(item), 'icon'),
    btn('×', '刪除文字', async () => {
      if (!confirm(
        '刪除「' + item.title + '」？此操作不能復原。'
      )) return;

      templates = templates.filter(t => t.id !== item.id);
      await persist({ templates });
      render();
      notify('已刪除文字 Template。');
    }, 'icon danger')
  );

  row.append(info, actions);
  card.append(row);

  return card;
}

function materialCard(item) {
  const card = el('article', 'card material-card');
  const row = el('div', 'row');

  row.append(reorderCard(card, item));

  let graphic;

  if (item.type === 'image') {
    graphic = el('img', 'thumb');
    graphic.src = item.url;
    graphic.alt = item.title;
    graphic.loading = 'lazy';
    graphic.title = '點擊預覽；拖曳可嘗試上載';

    graphic.addEventListener('click', () => preview(item));

    graphic.addEventListener('error', () => {
      graphic.alt = '圖片未能載入';
      graphic.title = '圖片未能載入，請檢查網絡或檔案路徑';
    }, { once: true });
  } else {
    graphic = el('div', 'file-icon', 'PDF');
    graphic.title = '雙擊開啟 PDF；建議下載後上載';
    graphic.addEventListener('dblclick', () =>
      chrome.tabs.create({ url: item.url })
    );
  }

  fileDrag(graphic, item);

  const info = el('div', 'info');
  const labelParts = [];

  if (materialGroup(item) === '新查詢進度圖') {
    labelParts.push(materialSubject(item));
  }

  if (item.category) labelParts.push(item.category);
  labelParts.push(item.type === 'image' ? '圖片' : 'PDF');

  info.append(
    el('div', 'title', item.title),
    el('span', 'label', labelParts.join(' · '))
  );

  const actions = el('div', 'material-actions');

  if (item.type === 'image') {
    actions.append(
      btn('⧉', '複製圖片',
        e => copyImage(item, e.currentTarget), 'icon'),
      btn('預覽', '預覽圖片', () => preview(item))
    );
  } else {
    actions.append(
      btn('開啟', '開啟 PDF', () =>
        chrome.tabs.create({ url: item.url })
      )
    );
  }

  actions.append(
    btn('↓ 下載', '下載檔案', () => download(item))
  );

  info.append(actions);
  row.append(graphic, info);
  card.append(row);

  return card;
}

function filename(item) {
  try {
    return decodeURIComponent(
      new URL(item.url).pathname.split('/').pop()
    );
  } catch {
    return item.type === 'pdf' ? 'material.pdf' : 'material.jpg';
  }
}

function fetchFile(item) {
  if (preparedFiles.has(item.url)) {
    return Promise.resolve(preparedFiles.get(item.url));
  }

  if (fileTasks.has(item.url)) {
    return fileTasks.get(item.url);
  }

  const task = (async () => {
    const response = await fetch(item.url, {
      cache: 'no-cache',
      signal: AbortSignal.timeout(30000)
    });

    if (!response.ok) {
      throw new Error('HTTP ' + response.status);
    }

    const blob = await response.blob();

    const file = new File([blob], filename(item), {
      type: blob.type || (
        item.type === 'pdf'
          ? 'application/pdf'
          : 'image/jpeg'
      )
    });

    preparedFiles.set(item.url, file);
    return file;
  })().finally(() => fileTasks.delete(item.url));

  fileTasks.set(item.url, task);

  return task;
}

function fileDrag(node, item) {
  node.draggable = true;

  const prepare = () => {
    fetchFile(item).catch(() => {});
  };

  node.addEventListener('mouseenter', prepare);
  node.addEventListener('pointerdown', prepare);

  node.addEventListener('dragstart', e => {
    e.stopPropagation();
    dragId = null;
    dragTab = null;
    e.dataTransfer.effectAllowed = 'copy';

    const file = preparedFiles.get(item.url);

    if (file) {
      try {
        e.dataTransfer.items.add(file);
      } catch {}
    }

    e.dataTransfer.setData(
      'DownloadURL',
      (file?.type || (
        item.type === 'pdf'
          ? 'application/pdf'
          : 'image/jpeg'
      )) + ':' + filename(item) + ':' + item.url
    );

    e.dataTransfer.setData('text/uri-list', item.url);
    e.dataTransfer.setData('text/plain', item.url);

    notify(file
      ? '拖曳支援視聊天平台而定；唔接受附件時請下載後上載。'
      : '檔案準備中，今次可能只拖出網址。可停留一下再拖，或下載後上載。'
    );
  });
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    notify('已複製文字，可貼到聊天輸入框。');
  } catch (e) {
    console.error(e);
    notify('複製失敗，請確認視窗已取得焦點。');
  }
}

async function toPng(item) {
  const file = await fetchFile(item);
  const bitmap = await createImageBitmap(file);

  try {
    const canvas = document.createElement('canvas');
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;

    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas unavailable');

    context.drawImage(bitmap, 0, 0);

    return await new Promise((resolve, reject) =>
      canvas.toBlob(
        blob => blob
          ? resolve(blob)
          : reject(new Error('圖片轉換失敗')),
        'image/png'
      )
    );
  } finally {
    bitmap.close();
  }
}

async function copyImage(item, button) {
  if (button) button.disabled = true;

  try {
    if (!navigator.clipboard?.write || !window.ClipboardItem) {
      throw new Error('此瀏覽器不支援圖片複製');
    }

    const png = toPng(item);

    await navigator.clipboard.write([
      new ClipboardItem({ 'image/png': png })
    ]);

    notify('已複製圖片。返回聊天輸入框按 Ctrl+V；Mac 用 ⌘V。');
  } catch (e) {
    console.error(e);
    notify('圖片複製失敗。請保持視窗焦點及檢查網絡，或改用下載。');
  } finally {
    if (button) button.disabled = false;
  }
}

async function download(item) {
  try {
    await chrome.downloads.download({
      url: item.url,
      filename: filename(item),
      saveAs: true,
      conflictAction: 'uniquify'
    });

    notify('已開啟下載／儲存對話框；儲存後可自行上載。');
  } catch (e) {
    console.error(e);
    notify('下載未開始或已取消。可以按「開啟」或再試。');
  }
}

function preview(item) {
  selected = item;

  $('preview-title').textContent = item.title;
  $('preview-img').src = item.url;
  $('preview-img').alt = item.title;
  $('preview').showModal();
}

function fillTemplateGroupOptions(value) {
  syncTextGroupsFromTemplates();

  const select = $('edit-group');
  if (!select) return;

  select.replaceChildren();

  textGroups.forEach(group => {
    const option = el('option');
    option.value = group;
    option.textContent = group;
    select.append(option);
  });

  const custom = el('option');
  custom.value = '__custom__';
  custom.textContent = '+ ...';
  select.append(custom);

  select.value = textGroups.includes(value)
    ? value
    : DEFAULT_TEXT_GROUP;

  select.onchange = async () => {
    if (select.value !== '__custom__') return;

    const name = prompt('請輸入新分組名稱：');
    const group = name ? name.trim() : '';

    if (!group) {
      select.value = DEFAULT_TEXT_GROUP;
      return;
    }

    if (group.length > 40) {
      notify('分組名稱最多 40 字。');
      select.value = DEFAULT_TEXT_GROUP;
      return;
    }

    if (!textGroups.includes(group)) {
      textGroups.push(group);
      textGroups = validateTextGroups(textGroups);
      await persist({ textGroups });
    }

    fillTemplateGroupOptions(group);
  };
}

function openEditor(item = null) {
  editingId = item?.id || null;

  $('editor-title').textContent = item
    ? '修改文字 Template'
    : '新增文字 Template';

  $('edit-title').value = item?.title || '';
  $('edit-content').value = item?.content || '';

  fillTemplateGroupOptions(
    item?.group || selectedTextGroup || DEFAULT_TEXT_GROUP
  );

  $('editor').showModal();
  $('edit-title').focus();
}

async function refreshMaterials(showMessage = true) {
  if (loading) return;

  loading = true;
  offline = false;

  const refreshButton = $('refresh');
  if (refreshButton) refreshButton.disabled = true;

  render();

  try {
    const response = await fetch(MANIFEST, {
      cache: 'no-store',
      signal: AbortSignal.timeout(20000)
    });

    if (!response.ok) {
      throw new Error('HTTP ' + response.status);
    }

    const items = validateMaterials(await response.json());

    materials = items;
    offline = false;
    lastUpdated = Date.now();
    preparedFiles.clear();

    const oldOrderSet = new Set(materialOrder);
    const newIds = items.map(item => item.id);

    materialOrder = [
      ...materialOrder.filter(id => newIds.includes(id)),
      ...newIds.filter(id => !oldOrderSet.has(id))
    ];

    await persist({
      materialsCache: items,
      materialOrder,
      lastUpdated
    });

    if (showMessage) {
      notify('教材已更新，共 ' + items.length + ' 份。');
    }
  } catch (e) {
    offline = true;
    console.error(e);

    notify(
      '未能更新教材：' + e.message + '。' +
      (materials.length
        ? '暫時保留上次清單；附件仍需網絡。'
        : '請檢查網絡及 GitHub Pages。')
    );
  } finally {
    loading = false;

    if (refreshButton) refreshButton.disabled = false;

    render();
  }
}

$('tab-text').addEventListener('click', () => switchTab('text'));
$('tab-materials').addEventListener('click', () => switchTab('materials'));

$('add').addEventListener('click', () => openEditor());

$('cancel-edit').addEventListener('click', () => {
  $('editor').close();
});

$('edit-form').addEventListener('submit', async e => {
  e.preventDefault();

  const title = $('edit-title').value.trim();
  const content = $('edit-content').value;
  const group = $('edit-group')?.value || DEFAULT_TEXT_GROUP;

  if (!title || !content.trim()) {
    return notify('請輸入名稱及文字內容。');
  }

  if (title.length > 120 || content.length > 100000) {
    return notify('名稱最多 120 字；內容最多 100000 字。');
  }

  if (!editingId && templates.length >= 2000) {
    return notify('最多支援 2000 份 Template。');
  }

  if (group === '__custom__') {
    return notify('請選擇有效分組。');
  }

  const item = {
    id: editingId || crypto.randomUUID(),
    title,
    content,
    group
  };

  const index = templates.findIndex(t => t.id === editingId);

  if (index >= 0) {
    templates[index] = item;
  } else {
    templates.push(item);
  }

  if (!textGroups.includes(group)) {
    textGroups.push(group);
    textGroups = validateTextGroups(textGroups);
  }

  await persist({ templates, textGroups });

  $('editor').close();
  render();
  notify('已儲存文字 Template。');
});

$('refresh').addEventListener('click', () => refreshMaterials());

$('close-preview').addEventListener('click', () => {
  $('preview').close();
});

$('preview-copy').addEventListener('click', e => {
  if (selected) copyImage(selected, e.currentTarget);
});

$('preview-download').addEventListener('click', () => {
  if (selected) download(selected);
});

$('export').addEventListener('click', () => {
  syncTextGroupsFromTemplates();

  const data = {
    app: 'cs-materials-templates',
    version: 2,
    exportedAt: new Date().toISOString(),
    textGroups,
    templates
  };

  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: 'application/json'
  });

  const url = URL.createObjectURL(blob);
  const a = el('a');

  a.href = url;
  a.download = 'cs-templates-' +
    new Date().toISOString().slice(0, 10) + '.json';

  document.body.append(a);
  a.click();
  a.remove();

  setTimeout(() => URL.revokeObjectURL(url), 30000);

  notify('已產生文字備份。備份可能包含私人文字，請妥善保存。');
});

$('import').addEventListener('click', () => {
  $('import-file').click();
});

$('import-file').addEventListener('change', async e => {
  const file = e.target.files[0];
  e.target.value = '';

  if (!file) return;

  try {
    if (file.size > 10 * 1024 * 1024) {
      throw new Error('備份檔案不能超過 10 MB。');
    }

    const data = JSON.parse(await file.text());

    if (data.app !== 'cs-materials-templates' ||
        ![1, 2].includes(data.version)) {
      throw new Error('請選擇由本插件匯出嘅備份。');
    }

    const incoming = validateTemplates(data.templates);

    if (!incoming.length) {
      return notify('備份沒有任何 Template。');
    }

    if (!confirm(
      '匯入 ' + incoming.length + ' 份文字？\n' +
      '會加到現有清單最後，不會覆蓋或刪除原有文字。' +
      '重複匯入可能產生副本。'
    )) return;

    if (templates.length + incoming.length > 2000) {
      throw new Error('匯入後會超過 2000 份 Template。');
    }

    templates.push(...incoming.map(t => ({
      ...t,
      id: crypto.randomUUID()
    })));

    textGroups = validateTextGroups([
      ...textGroups,
      ...(data.version === 2 ? data.textGroups || [] : []),
      ...incoming.map(t => t.group || DEFAULT_TEXT_GROUP)
    ]);

    await persist({ templates, textGroups });

    render();
    notify('已匯入 ' + incoming.length + ' 份文字。');
  } catch (e) {
    console.error(e);
    notify('匯入失敗：' + e.message);
  }
});

async function init() {
  try {
    installFilterStyles();
    ensureGroupEditButton();

    const data = await chrome.storage.local.get([
      'templates',
      'textGroups',
      'materialsCache',
      'materialOrder',
      'lastUpdated'
    ]);

    try {
      templates = validateTemplates(data.templates || []);
      textGroups = validateTextGroups(data.textGroups || []);
      syncTextGroupsFromTemplates();
    } catch (e) {
      console.error(e);
      notify('本機文字格式有問題，請勿新增覆蓋，先聯絡管理員。');
      return;
    }

    try {
      materials = validateMaterials({
        items: data.materialsCache || []
      });
    } catch (e) {
      console.warn('本機教材快取格式有問題，已略過。', e);
      materials = [];
    }

    materialOrder = Array.isArray(data.materialOrder)
      ? data.materialOrder.filter(id => typeof id === 'string')
      : [];

    lastUpdated = typeof data.lastUpdated === 'number'
      ? data.lastUpdated
      : null;

    switchTab('text');

    await refreshMaterials(false);
  } catch (e) {
    console.error(e);
    notify('初始化失敗，請重新載入插件。');
  }
}

init();

