
  'use strict';

const BASE = 'https://unieduptcs.github.io/cs-materials/';
const MANIFEST = BASE + 'materials.json';
const $ = id => document.getElementById(id);

const MATERIAL_GROUPS = ['常用圖', '新查詢進度圖', '限時活動'];
let selectedGroup = '常用圖';
let selectedSubject = '';

let templates = [], materials = [], materialOrder = [];
let tab = 'text', editingId = null, selected = null;
let dragId = null, dragTab = null, lastUpdated = null;
let offline = false, loading = false, toastTimer;

const preparedFiles = new Map();
const fileTasks = new Map();
let saveQueue = Promise.resolve();

function notify(message) {
  $('toast').textContent = message;
  $('toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    $('toast').hidden = true;
  }, 4500);
}

function persist(data) {
  saveQueue = saveQueue
    .then(() => chrome.storage.local.set(data))
    .catch(e => {
      console.error(e);
      notify('儲存失敗，請匯出備份並檢查儲存空間。');
    });
  return saveQueue;
}

function el(tag, cls, text) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

function btn(label, title, handler, cls = '') {
  const node = el('button', cls, label);
  node.type = 'button';
  node.title = title;
  node.setAttribute('aria-label', title);
  node.addEventListener('click', handler);
  return node;
}

function installFilterStyles() {
  if ($('material-filter-styles')) return;

  const style = el('style');
  style.id = 'material-filter-styles';
  style.textContent = `
    #material-filters {
      margin: 0 0 10px;
    }
    #material-filters .filter-row {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
    }
    #material-filters .filter-button {
      padding: 6px 9px;
      font-size: 12px;
      line-height: 1.4;
      border: 1px solid #dce2ec;
      border-radius: 7px;
      background: #fff;
      color: #3b4a60;
      cursor: pointer;
    }
    #material-filters .group-filters .filter-button {
      flex: 1;
      white-space: nowrap;
    }
    #material-filters .filter-button:hover {
      background: #eef3ff;
      border-color: #b6c8f8;
    }
    #material-filters .filter-button.active {
      color: #315bc7;
      background: #edf3ff;
      border-color: #b8c9f4;
      font-weight: 600;
    }
    #material-filters .subject-filters {
      margin-top: 7px;
    }
    #material-filters .subject-filters .filter-button {
      padding: 4px 9px;
      font-size: 11px;
    }
    #material-filters .filter-button:focus-visible {
      outline: 2px solid #4270e0;
      outline-offset: 2px;
    }
    #material-filters[hidden] {
      display: none !important;
    }
  `;
  document.head.append(style);
}

function validateTemplates(value) {
  if (!Array.isArray(value) || value.length > 2000) {
    throw new Error('Template 清單格式不正確或數量過多。');
  }

  const ids = new Set();

  return value.map(t => {
    if (!t || typeof t.title !== 'string' || !t.title.trim() ||
        typeof t.content !== 'string' || !t.content.trim() ||
        t.title.length > 120 || t.content.length > 100000) {
      throw new Error('每份 Template 必須有有效名稱及內容。');
    }

    let id = typeof t.id === 'string' && t.id &&
      t.id.length <= 100 ? t.id : crypto.randomUUID();

    if (ids.has(id)) id = crypto.randomUUID();
    ids.add(id);

    return { id, title: t.title, content: t.content };
  });
}

function validateMaterials(data) {
  if (!data || !Array.isArray(data.items) ||
      data.items.length > 1000) {
    throw new Error('教材清單格式不正確。');
  }

  const ids = new Set();
  const assetsBase = new URL('assets/', BASE);

  return data.items.map(m => {
    if (!m || typeof m.id !== 'string' || !m.id ||
        typeof m.title !== 'string' || !m.title ||
        !['image', 'pdf'].includes(m.type) ||
        typeof m.path !== 'string' || !m.path.trim()) {
      throw new Error('教材項目缺少必要欄位。');
    }

    const path = m.path.trim();
    let url;

    try {
      url = new URL(path, BASE);
    } catch {
      throw new Error('教材路徑格式不正確：' + m.title);
    }

    if (url.origin !== assetsBase.origin ||
        !url.pathname.startsWith(assetsBase.pathname) ||
        url.username || url.password) {
      throw new Error(
        '教材檔案必須放在公司 assets 資料夾：' +
        m.title + '（解析網址：' + url.href + '）'
      );
    }

    if (ids.has(m.id)) {
      throw new Error('教材 ID 重複：' + m.id);
    }
    ids.add(m.id);

    const group = typeof m.group === 'string'
      ? m.group.trim() : '';

    // 缺少 group 的旧教材歸入常用圖；拼錯分類則提示管理員。
    if (group && !MATERIAL_GROUPS.includes(group)) {
      throw new Error(
        '教材分類不正確：' + m.title +
        '（group：' + group +
        '；請使用常用圖、新查詢進度圖或限時活動）'
      );
    }

    return {
      id: m.id,
      title: m.title,
      type: m.type,
      category: typeof m.category === 'string'
        ? m.category : '',
      group: group || '常用圖',
      subject: typeof m.subject === 'string' && m.subject.trim()
        ? m.subject.trim() : '其他',
      path,
      url: url.href
    };
  });
}

function orderedMaterials() {
  const ranks = new Map(
    materialOrder.map((id, i) => [id, i])
  );
  return [...materials].sort((a, b) =>
    (ranks.get(a.id) ?? 100000) -
    (ranks.get(b.id) ?? 100000)
  );
}

function materialGroup(item) {
  return item.group || '常用圖';
}

function materialSubject(item) {
  return item.subject || '其他';
}

function renderMaterialFilters() {
  let panel = $('material-filters');

  if (!panel) {
    panel = el('div', 'material-filters');
    panel.id = 'material-filters';
    const search = $('search');
    search.parentNode.insertBefore(panel, search);
  }

  panel.hidden = tab !== 'materials';
  panel.replaceChildren();
  if (tab !== 'materials') return;

  const groupRow = el('div', 'filter-row group-filters');
  groupRow.setAttribute('role', 'group');
  groupRow.setAttribute('aria-label', '教材分類');

  for (const group of MATERIAL_GROUPS) {
    const active = selectedGroup === group;
    const button = btn(
      group,
      '顯示' + group,
      () => {
        selectedGroup = group;
        selectedSubject = '';
        $('search').value = '';
        render();
      },
      'filter-button' + (active ? ' active' : '')
    );

    button.setAttribute('aria-pressed', String(active));
    groupRow.append(button);
  }

  panel.append(groupRow);

  if (selectedGroup !== '新查詢進度圖') return;

  const subjects = [...new Set(
    materials
      .filter(item => materialGroup(item) === selectedGroup)
      .map(materialSubject)
  )].sort((a, b) => {
    if (a === b) return 0;
    if (a === '其他') return 1;
    if (b === '其他') return -1;
    return a.localeCompare(b, 'zh-HK');
  });

  if (selectedSubject && !subjects.includes(selectedSubject)) {
    selectedSubject = '';
  }

  const subjectRow = el('div', 'filter-row subject-filters');
  subjectRow.setAttribute('role', 'group');
  subjectRow.setAttribute('aria-label', '科目分類');

  function addSubjectButton(label, value) {
    const active = selectedSubject === value;
    const button = btn(
      label,
      '顯示' + label,
      () => {
        selectedSubject = value;
        $('search').value = '';
        render();
      },
      'filter-button' + (active ? ' active' : '')
    );

    button.setAttribute('aria-pressed', String(active));
    subjectRow.append(button);
  }

  addSubjectButton('全部科目', '');
  subjects.forEach(subject => addSubjectButton(subject, subject));
  panel.append(subjectRow);
}

function switchTab(value) {
  tab = value;
  $('search').value = '';

  const text = tab === 'text';
  $('tab-text').classList.toggle('active', text);
  $('tab-materials').classList.toggle('active', !text);
  $('tab-text').setAttribute('aria-pressed', String(text));
  $('tab-materials').setAttribute('aria-pressed', String(!text));
  $('tools-text').hidden = !text;
  $('tools-materials').hidden = text;

  $('hint').textContent = text
    ? '拖動 ⋮⋮ 排序。文字只儲存在此 Chrome 個人資料中。'
    : '⋮⋮ 用作排序；PDF 建議下載後從檔案總管拖到聊天視窗。';

  render();
}

function render() {
  renderMaterialFilters();

  const list = $('list');
  list.replaceChildren();

  const q = $('search').value.trim().toLocaleLowerCase();
  const isText = tab === 'text';
  let source = isText ? templates : orderedMaterials();

  if (!isText) {
    source = source.filter(
      item => materialGroup(item) === selectedGroup
    );

    if (selectedGroup === '新查詢進度圖' && selectedSubject) {
      source = source.filter(
        item => materialSubject(item) === selectedSubject
      );
    }
  }

  const visible = source.filter(item =>
    [
      item.title,
      item.content || '',
      item.category || '',
      item.group || '',
      item.subject || ''
    ].join(' ').toLocaleLowerCase().includes(q)
  );

  $('search').placeholder = isText
    ? '搜尋名稱或文字…'
    : '搜尋目前分類的教材…';

  $('meta').textContent = isText
    ? visible.length + ' / ' + templates.length +
      ' 份文字 · 本機儲存'
    : selectedGroup +
      (selectedGroup === '新查詢進度圖' && selectedSubject
        ? ' · ' + selectedSubject : '') +
      ' · ' + visible.length + ' / ' + source.length +
      ' 份 · 全部教材 ' + materials.length +
      (loading ? ' · 更新中…' : '') +
      (offline ? ' · 更新失敗，顯示上次清單' : '') +
      (lastUpdated
        ? ' · 上次同步 ' +
          new Date(lastUpdated).toLocaleString('zh-HK')
        : '');

  if (!visible.length) {
    const message = q
      ? '搵唔到符合搜尋條件的資料。'
      : isText
        ? '未有文字 Template。\n按「＋ 新增文字」開始。'
        : loading
          ? '正在讀取公司教材…'
          : !materials.length
            ? '未有教材。請按「重新整理教材」。'
            : '此分類暫時未有教材。';

    list.append(el('div', 'empty', message));
    return;
  }

  for (const item of visible) {
    list.append(isText ? textCard(item) : materialCard(item));
  }
}

function reorderCard(card, item) {
  const grip = btn('⋮⋮', '拖動排序', () => {}, 'grip');
  grip.draggable = true;

  grip.addEventListener('dragstart', e => {
    dragId = item.id;
    dragTab = tab;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('application/x-cs-sort', item.id);
    e.dataTransfer.setData('text/plain', item.title);
    card.classList.add('dragging');
  });

  grip.addEventListener('dragend', () => {
    dragId = null;
    dragTab = null;
    document.querySelectorAll('.dragging,.over').forEach(n =>
      n.classList.remove('dragging', 'over')
    );
  });

  card.addEventListener('dragover', e => {
    if (dragId && dragTab === tab && dragId !== item.id) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      card.classList.add('over');
    }
  });

  card.addEventListener('dragleave', e => {
    if (!card.contains(e.relatedTarget)) {
      card.classList.remove('over');
    }
  });

  card.addEventListener('drop', e => {
    if (!dragId || dragTab !== tab) return;
    e.preventDefault();
    card.classList.remove('over');
    if (dragId === item.id) return;

    const ids = tab === 'text'
      ? templates.map(t => t.id)
      : orderedMaterials().map(m => m.id);

    const from = ids.indexOf(dragId);
    if (from < 0 || !ids.includes(item.id)) return;

    ids.splice(from, 1);
    ids.splice(ids.indexOf(item.id), 0, dragId);

    if (tab === 'text') {
      const lookup = new Map(templates.map(t => [t.id, t]));
      templates = ids.map(id => lookup.get(id));
      persist({ templates });
    } else {
      materialOrder = ids;
      persist({ materialOrder });
    }

    dragId = null;
    dragTab = null;
    render();
  });

  return grip;
}

function textCard(item) {
  const card = el('article', 'card text-card');
  const row = el('div', 'row');
  row.append(reorderCard(card, item));

  const info = el('div', 'info');
  info.append(
    el('div', 'title', item.title),
    el('div', 'text-content', item.content)
  );

  const actions = el('div', 'actions');
  actions.append(
    btn('⧉', '複製文字', () => copyText(item.content), 'icon'),
    btn('✎', '修改文字', () => openEditor(item), 'icon'),
    btn('×', '刪除文字', async () => {
      if (!confirm(
        '刪除「' + item.title + '」？此操作不能復原。'
      )) return;

      templates = templates.filter(t => t.id !== item.id);
      await persist({ templates });
      render();
      notify('已刪除文字 Template。');
    }, 'icon danger')
  );

  row.append(info, actions);
  card.append(row);
  return card;
}

function materialCard(item) {
  const card = el('article', 'card material-card');
  const row = el('div', 'row');
  row.append(reorderCard(card, item));

  let graphic;

  if (item.type === 'image') {
    graphic = el('img', 'thumb');
    graphic.src = item.url;
    graphic.alt = item.title;
    graphic.loading = 'lazy';
    graphic.title = '點擊預覽；拖曳可嘗試上載';
    graphic.addEventListener('click', () => preview(item));
    graphic.addEventListener('error', () => {
      graphic.alt = '圖片未能載入';
      graphic.title = '圖片未能載入，請檢查網絡或檔案路徑';
    }, { once: true });
  } else {
    graphic = el('div', 'file-icon', 'PDF');
    graphic.title = '雙擊開啟 PDF；建議下載後上載';
    graphic.addEventListener('dblclick', () =>
      chrome.tabs.create({ url: item.url })
    );
  }

  fileDrag(graphic, item);

  const info = el('div', 'info');
  const labelParts = [];

  if (materialGroup(item) === '新查詢進度圖') {
    labelParts.push(materialSubject(item));
  }
  if (item.category) labelParts.push(item.category);
  labelParts.push(item.type === 'image' ? '圖片' : 'PDF');

  info.append(
    el('div', 'title', item.title),
    el('span', 'label', labelParts.join(' · '))
  );

  const actions = el('div', 'material-actions');

  if (item.type === 'image') {
    actions.append(
      btn('⧉', '複製圖片',
        e => copyImage(item, e.currentTarget), 'icon'),
      btn('預覽', '預覽圖片', () => preview(item))
    );
  } else {
    actions.append(
      btn('開啟', '開啟 PDF', () =>
        chrome.tabs.create({ url: item.url })
      )
    );
  }

  actions.append(
    btn('↓ 下載', '下載檔案', () => download(item))
  );

  info.append(actions);
  row.append(graphic, info);
  card.append(row);
  return card;
}

function filename(item) {
  try {
    return decodeURIComponent(
      new URL(item.url).pathname.split('/').pop()
    );
  } catch {
    return item.type === 'pdf' ? 'material.pdf' : 'material.jpg';
  }
}

function fetchFile(item) {
  if (preparedFiles.has(item.url)) {
    return Promise.resolve(preparedFiles.get(item.url));
  }
  if (fileTasks.has(item.url)) {
    return fileTasks.get(item.url);
  }

  const task = (async () => {
    const response = await fetch(item.url, {
      cache: 'no-cache',
      signal: AbortSignal.timeout(30000)
    });

    if (!response.ok) {
      throw new Error('HTTP ' + response.status);
    }

    const blob = await response.blob();
    const file = new File([blob], filename(item), {
      type: blob.type || (
        item.type === 'pdf'
          ? 'application/pdf' : 'image/jpeg'
      )
    });

    preparedFiles.set(item.url, file);
    return file;
  })().finally(() => fileTasks.delete(item.url));

  fileTasks.set(item.url, task);
  return task;
}

function fileDrag(node, item) {
  node.draggable = true;

  const prepare = () => {
    fetchFile(item).catch(() => {});
  };

  node.addEventListener('mouseenter', prepare);
  node.addEventListener('pointerdown', prepare);
  node.addEventListener('dragstart', e => {
    e.stopPropagation();
    dragId = null;
    dragTab = null;
    e.dataTransfer.effectAllowed = 'copy';

    const file = preparedFiles.get(item.url);

    if (file) {
      try {
        e.dataTransfer.items.add(file);
      } catch {}
    }

    e.dataTransfer.setData(
      'DownloadURL',
      (file?.type || (
        item.type === 'pdf'
          ? 'application/pdf' : 'image/jpeg'
      )) + ':' + filename(item) + ':' + item.url
    );
    e.dataTransfer.setData('text/uri-list', item.url);
    e.dataTransfer.setData('text/plain', item.url);

    notify(file
      ? '拖曳支援視聊天平台而定；唔接受附件時請下載後上載。'
      : '檔案準備中，今次可能只拖出網址。可停留一下再拖，或下載後上載。'
    );
  });
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    notify('已複製文字，可貼到聊天輸入框。');
  } catch (e) {
    console.error(e);
    notify('複製失敗，請確認視窗已取得焦點。');
  }
}

async function toPng(item) {
  const file = await fetchFile(item);
  const bitmap = await createImageBitmap(file);

  try {
    const canvas = document.createElement('canvas');
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;

    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas unavailable');

    context.drawImage(bitmap, 0, 0);

    return await new Promise((resolve, reject) =>
      canvas.toBlob(
        blob => blob
          ? resolve(blob)
          : reject(new Error('圖片轉換失敗')),
        'image/png'
      )
    );
  } finally {
    bitmap.close();
  }
}

async function copyImage(item, button) {
  if (button) button.disabled = true;

  try {
    if (!navigator.clipboard?.write || !window.ClipboardItem) {
      throw new Error('此瀏覽器不支援圖片複製');
    }

    const png = toPng(item);
    await navigator.clipboard.write([
      new ClipboardItem({ 'image/png': png })
    ]);

    notify('已複製圖片。返回聊天輸入框按 Ctrl+V；Mac 用 ⌘V。');
  } catch (e) {
    console.error(e);
    notify('圖片複製失敗。請保持視窗焦點及檢查網絡，或改用下載。');
  } finally {
    if (button) button.disabled = false;
  }
}

async function download(item) {
  try {
    await chrome.downloads.download({
      url: item.url,
      filename: filename(item),
      saveAs: true,
      conflictAction: 'uniquify'
    });
    notify('已開啟下載／儲存對話框；儲存後可自行上載。');
  } catch (e) {
    console.error(e);
    notify('下載未開始或已取消。可以按「開啟」或再試。');
  }
}

function preview(item) {
  selected = item;
  $('preview-title').textContent = item.title;
  $('preview-img').src = item.url;
  $('preview-img').alt = item.title;
  $('preview').showModal();
}

function openEditor(item = null) {
  editingId = item?.id || null;
  $('editor-title').textContent = item
    ? '修改文字 Template' : '新增文字 Template';
  $('edit-title').value = item?.title || '';
  $('edit-content').value = item?.content || '';
  $('editor').showModal();
  $('edit-title').focus();
}

async function refresh(showMessage = true) {
  if (loading) return;

  loading = true;
  $('refresh').disabled = true;
  render();

  try {
    const response = await fetch(MANIFEST, {
      cache: 'no-store',
      signal: AbortSignal.timeout(20000)
    });

    if (!response.ok) {
      throw new Error('HTTP ' + response.status);
    }

    const items = validateMaterials(await response.json());
    materials = items;
    offline = false;
    lastUpdated = Date.now();
    preparedFiles.clear();
    materialOrder = orderedMaterials().map(m => m.id);

    await persist({
      materialsCache: items,
      materialOrder,
      lastUpdated
    });

    if (showMessage) {
      notify('教材已更新，共 ' + items.length + ' 份。');
    }
  } catch (e) {
    offline = true;
    console.error(e);
    notify(
      '未能更新教材：' + e.message + '。' +
      (materials.length
        ? '暫時保留上次清單；附件仍需網絡。'
        : '請檢查網絡及 GitHub Pages。')
    );
  } finally {
    loading = false;
    $('refresh').disabled = false;
    render();
  }
}

$('tab-text').addEventListener('click', () => switchTab('text'));
$('tab-materials').addEventListener('click', () =>
  switchTab('materials')
);
$('search').addEventListener('input', render);
$('add').addEventListener('click', () => openEditor());
$('cancel-edit').addEventListener('click', () =>
  $('editor').close()
);

$('edit-form').addEventListener('submit', async e => {
  e.preventDefault();

  const title = $('edit-title').value.trim();
  const content = $('edit-content').value;

  if (!title || !content.trim()) {
    return notify('請輸入名稱及文字內容。');
  }
  if (title.length > 120 || content.length > 100000) {
    return notify('名稱最多 120 字；內容最多 100000 字。');
  }
  if (!editingId && templates.length >= 2000) {
    return notify('最多支援 2000 份 Template。');
  }

  const item = {
    id: editingId || crypto.randomUUID(),
    title,
    content
  };

  const index = templates.findIndex(t => t.id === editingId);
  if (index >= 0) templates[index] = item;
  else templates.push(item);

  await persist({ templates });
  $('editor').close();
  render();
  notify('已儲存文字 Template。');
});

$('refresh').addEventListener('click', () => refresh());
$('close-preview').addEventListener('click', () =>
  $('preview').close()
);
$('preview-copy').addEventListener('click', e =>
  selected && copyImage(selected, e.currentTarget)
);
$('preview-download').addEventListener('click', () =>
  selected && download(selected)
);

$('export').addEventListener('click', () => {
  const data = {
    app: 'cs-materials-templates',
    version: 1,
    exportedAt: new Date().toISOString(),
    templates
  };

  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: 'application/json'
  });
  const url = URL.createObjectURL(blob);
  const a = el('a');

  a.href = url;
  a.download = 'cs-templates-' +
    new Date().toISOString().slice(0, 10) + '.json';

  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
  notify('已產生文字備份。備份可能包含私人文字，請妥善保存。');
});

$('import').addEventListener('click', () =>
  $('import-file').click()
);

$('import-file').addEventListener('change', async e => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;

  try {
    if (file.size > 10 * 1024 * 1024) {
      throw new Error('備份檔案不能超過 10 MB。');
    }

    const data = JSON.parse(await file.text());
    if (data.app !== 'cs-materials-templates' ||
        data.version !== 1) {
      throw new Error('請選擇由本插件匯出嘅備份。');
    }

    const incoming = validateTemplates(data.templates);
    if (!incoming.length) {
      return notify('備份沒有任何 Template。');
    }

    if (!confirm(
      '匯入 ' + incoming.length + ' 份文字？\n' +
      '會加到現有清單最後，不會覆蓋或刪除原有文字。' +
      '重複匯入可能產生副本。'
    )) return;

    if (templates.length + incoming.length > 2000) {
      throw new Error('匯入後會超過 2000 份 Template。');
    }

    templates.push(...incoming.map(t => ({
      ...t,
      id: crypto.randomUUID()
    })));

    await persist({ templates });
    render();
    notify('已匯入 ' + incoming.length + ' 份文字。');
  } catch (e) {
    notify('匯入失敗：' + e.message);
  }
});

async function init() {
  try {
    installFilterStyles();

    const data = await chrome.storage.local.get([
      'templates',
      'materialsCache',
      'materialOrder',
      'lastUpdated'
    ]);

    try {
      templates = validateTemplates(data.templates || []);
    } catch (e) {
      notify('本機文字格式有問題，請勿新增覆蓋，先聯絡管理員。');
      console.error(e);
      return;
    }

    try {
      materials = validateMaterials({
        items: data.materialsCache || []
      });
    } catch {
      materials = [];
    }

    materialOrder = Array.isArray(data.materialOrder)
      ? data.materialOrder.filter(id => typeof id === 'string')
      : [];

    lastUpdated = typeof data.lastUpdated === 'number'
      ? data.lastUpdated : null;

    switchTab('text');
    await refresh(false);
  } catch (e) {
    console.error(e);
    notify('初始化失敗，請重新載入插件。');
  }
}

init();